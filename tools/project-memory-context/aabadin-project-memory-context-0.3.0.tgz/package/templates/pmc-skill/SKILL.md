# PMC-Aware Workflow

PMC first, files second.

Before reading more than 3 files, query PMC for structural context first. Use PMC to understand symbols, dependencies, and callers before falling back to raw file reads.

## Rule of thumb

- Query PMC before reading more than 3 files.
- Prefer PMC summaries for architecture, dependencies, and symbol lookup.
- Read source files after PMC when you need exact implementation details.

## Available commands

- `/map-project`
- `/get-context`
- `/enrich-status`
- `/doctor`
- `/init-project`
- `/sync-context`
- `/sanitize`

- `/get-context <target> [depth] [focus]`—resolve a symbol, file, or query and return structural context

## Available MCP tools

- `pmc_query_project`
- `pmc_search_symbols`
- `pmc_get_dependents`
- `pmc_get_dependencies`

## Why this saves tokens

PMC returns focused structural context, so the agent can avoid loading many full files into context. Querying graph-backed summaries first usually costs fewer tokens than broad file reads and helps reserve file inspection for the exact places that matter.
