#!/usr/bin/env node
import { createInterface } from 'node:readline/promises';
import { stdin as input, stdout as output } from 'node:process';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

import { bootstrapProjectInstall } from '../src/setup-bootstrap.mjs';
import { runDoctor } from '../src/doctor.mjs';
import { resolvePythonBin } from '../src/platform.mjs';

const packageRoot = dirname(dirname(fileURLToPath(import.meta.url)));

function installGraphify() {
  const candidates = process.platform === 'win32' ? ['python', 'py'] : ['python3', 'python'];
  for (const command of candidates) {
    const result = spawnSync(command, ['-m', 'pip', 'install', 'graphifyy'], { stdio: 'inherit' });
    if (result.status === 0) return command;
  }
  console.warn('\n⚠  Could not install graphifyy automatically. Run: pip install graphifyy\n');
  return null;
}

function spawnCheck(bin, args) {
  const result = spawnSync(bin, args, { encoding: 'utf-8', timeout: 5000 });
  return { exitCode: result.status ?? 1, stdout: result.stdout ?? '', stderr: result.stderr ?? '' };
}

const rl = createInterface({ input, output });
const cwd = resolve(process.cwd());

try {
  console.log('\n─── pmc setup ───────────────────────────────────────\n');

  const ollamaBaseUrl =
    (await rl.question('Ollama base URL [http://localhost:11434]: ')).trim() ||
    'http://localhost:11434';

  const ollamaModel =
    (await rl.question('Ollama model name [deepseek-coder-v2:16b-ctx32k]: ')).trim() ||
    'deepseek-coder-v2:16b-ctx32k';

  installGraphify();

  const result = await bootstrapProjectInstall({
    projectRoot: cwd,
    packageRoot,
    ollamaBaseUrl,
    ollamaModel,
  });

  console.log('\n─── Installation complete ───────────────────────────\n');
  console.log(`  Memory DB path:     ${result.installState.memoryDbPath}`);
  console.log(`  Embedding cache:    ${result.installState.embeddingCachePath}`);
  console.log(`  MCP config:         ${result.configPath}`);
  console.log(`  Command template:   ${result.commandPath}`);

  // Run doctor to surface any remaining issues
  console.log('\n─── Environment check ───────────────────────────────\n');
  const env = {
    ...process.env,
    MEMORY_DB_PATH: result.installState.memoryDbPath,
    EMBEDDING_CACHE_PATH: result.installState.embeddingCachePath,
  };
  const { checks } = await runDoctor({ env, resolvePythonBin, spawnCheck });

  const icon = { ok: '✓', warn: '⚠', fail: '✗' };
  for (const c of checks) {
    console.log(`  ${icon[c.status]}  ${c.name.padEnd(22)} ${c.message}`);
  }

  const hasFail = checks.some(c => c.status === 'fail');
  if (hasFail) {
    console.log('\nFix the issues above and re-run `pmc setup` if needed.\n');
  } else {
    console.log('\nAll checks passed. Run `pmc enrich` to start enriching the project.\n');
  }
} finally {
  rl.close();
}
