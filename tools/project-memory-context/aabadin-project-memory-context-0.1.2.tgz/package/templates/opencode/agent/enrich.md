---
name: enrich
description: Run batch semantic enrichment for pending symbols using the fallback chain.
argument-hint: "[--concurrency N]"
allowed-tools:
  - Bash
  - Read
  - Write
---

<objective>
Run batch semantic enrichment for all pending symbols in the worklist. Uses the fallback chain: local-model -> cloud-api -> agent-subagent.
</objective>

<execution>
Run:

```bash
{{PMC_BIN}} enrich . --concurrency 3
```

Each symbol gets enriched with a semantic report describing responsibility, inputs, outputs, dependencies, and role. Results are persisted and the sync-manifest is updated.
</execution>

<success_criteria>
- All pending symbols processed (enriched or marked as error)
- Sync-manifest updated with new entries
</success_criteria>
