<!-- pmc:autostart -->
When starting a session in a project with `.planning/project-memory-context/`:

1. Check `.planning/project-memory-context/enrichment/worklist.json` for pending or stale entries.
2. If pending/stale entries exist, launch background enrichment:
   ```bash
   {{PMC_BIN}} enrich .
   ```
3. Check `.planning/project-memory-context/enrichment/sync-manifest.json` for pending entries.
4. If sync-manifest has pending entries, remind the user: "PMC has {n} pending sync operations. Run `/sync-context` to apply them."
5. Search agent-memory for `project context overview` to fetch base context (stack, architecture, structure). Present a brief summary to establish session context.
6. Remind the user: "Use `/get-context <target>` for structural deep-dive before reading files."
<!-- /pmc:autostart -->
