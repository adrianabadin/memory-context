---
name: sync-context
description: Upsert enriched memories from the sync-manifest into agent-memory.
argument-hint: ""
allowed-tools:
  - Bash
---

<objective>
Process `.planning/project-memory-context/enrichment/sync-manifest.json` and upsert pending entries into `{{AGENT_MEMORY_CMD}}`.
</objective>

<execution>
Run the sync using `agent-memory` MCP tools. For each pending entry in the sync-manifest, call `agent-memory_store` or `agent-memory_update` with the enrichment payload.

After processing, mark entries as `synced` in the sync-manifest.
</execution>

<success_criteria>
- All pending entries in sync-manifest marked as `synced`
- No orphaned memories remaining
</success_criteria>
