---
name: get-context
description: Retrieve structured project context from agent-memory for the current project.
argument-hint: "<target>"
allowed-tools:
  - Bash
  - Read
---

<objective>
Retrieve and display structured project context from agent-memory. Use before reading files to get a structural overview.
</objective>

<execution>
Run:

```bash
{{PMC_BIN}} context . --refresh
```

This materializes or refreshes the 9 base project-context memories and outputs a summary.
</execution>
