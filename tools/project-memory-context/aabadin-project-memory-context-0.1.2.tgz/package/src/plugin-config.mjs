export function buildInjectedPmcConfig({ installState }) {
  return {
    mcp: {
      'pmc-agent-memory': {
        type: 'local',
        command: ['npx', '-y', '@aabadin/agent-memory-mcp'],
        enabled: true,
        environment: {
          MEMORY_DB_PATH: installState.memoryDbPath,
          EMBEDDING_MODEL: 'Xenova/bge-m3',
          EMBEDDING_DIMENSIONS: '1024',
          EMBEDDING_POOLING: 'cls',
        },
      },
    },
  };
}
