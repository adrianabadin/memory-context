const DEPTH_PRESETS = {
  compact: { maxHops: 1, includeCommunity: false, maxTokens: 2000, readSourceFiles: false },
  extended: { maxHops: 2, includeCommunity: true, maxTokens: 5000, readSourceFiles: false },
  deep: { maxHops: 3, includeCommunity: true, maxTokens: 10000, readSourceFiles: false },
  disk: { maxHops: 3, includeCommunity: true, maxTokens: 15000, readSourceFiles: true },
};

export function createDepthConfig(depth) {
  const preset = DEPTH_PRESETS[depth] ?? DEPTH_PRESETS.compact;
  return { ...preset };
}

function parseSymbolKeyParts(key) {
  return key.split('|');
}

function extractName(parts) {
  return parts.length >= 5 ? parts[parts.length - 2] : null;
}

function extractFilePath(parts) {
  return parts.length >= 2 ? parts[1] : null;
}

function normalizePath(filePath) {
  return String(filePath ?? '').replace(/\\/g, '/');
}

export function focusToEdgeTypes(focus) {
  const map = {
    dependencies: ['imports', 'imports_from'],
    callers: ['calls'],
    containment: ['contains', 'method'],
  };
  return map[focus] ?? ['calls', 'imports', 'imports_from', 'contains', 'method'];
}

export function createQueryEngine({ graph, symbolIndex, worklist, enrichmentDir, projectSlug }) {
  const nodeMap = new Map();
  for (const node of graph.nodes ?? []) {
    nodeMap.set(node.id, node);
  }

  const graphNodeIdToSymbolKeyMap = new Map();
  const nameToSymbolKeys = new Map();
  const filePathToSymbolKeys = new Map();

  for (const key of Object.keys(symbolIndex)) {
    const entry = symbolIndex[key];
    if (entry.graphNodeId) {
      graphNodeIdToSymbolKeyMap.set(entry.graphNodeId, key);
    }

    const parts = parseSymbolKeyParts(key);
    const name = extractName(parts);
    if (name) {
      const arr = nameToSymbolKeys.get(name);
      if (arr) {
        arr.push(key);
      } else {
        nameToSymbolKeys.set(name, [key]);
      }
    }

    const fp = extractFilePath(parts);
    if (fp) {
      const normalized = normalizePath(fp);
      const arr = filePathToSymbolKeys.get(normalized);
      if (arr) {
        arr.push(key);
      } else {
        filePathToSymbolKeys.set(normalized, [key]);
      }
    }
  }

  const links = graph.links ?? [];

  function traverseGraph({ nodeIds, maxHops, edgeTypes, direction }) {
    const types = edgeTypes ?? ['calls', 'imports', 'imports_from', 'contains', 'method'];
    const dir = direction ?? 'outbound';

    const visited = new Set();
    const resultNodes = [];
    const resultEdges = [];
    let frontier = [];

    for (const id of nodeIds) {
      const node = nodeMap.get(id);
      if (!node) continue;
      visited.add(id);
      resultNodes.push(node);
      frontier.push(id);
    }

    let depthReached = 0;

    for (let hop = 0; hop < maxHops; hop++) {
      const nextFrontier = [];
      for (const nodeId of frontier) {
        for (const link of links) {
          if (!types.includes(link.relation)) continue;
          let neighbor = null;
          if (dir === 'outbound' && link.source === nodeId) {
            neighbor = link.target;
          } else if (dir === 'inbound' && link.target === nodeId) {
            neighbor = link.source;
          }
          if (neighbor != null && !visited.has(neighbor)) {
            visited.add(neighbor);
            const neighborNode = nodeMap.get(neighbor);
            if (neighborNode) {
              resultNodes.push(neighborNode);
              resultEdges.push(link);
              nextFrontier.push(neighbor);
            }
          }
        }
      }
      if (nextFrontier.length === 0) break;
      frontier = nextFrontier;
      depthReached = hop + 1;
    }

    return { nodes: resultNodes, edges: resultEdges, depth_reached: depthReached };
  }

  function resolveWorklistEntry(symbolKey) {
    return (worklist ?? []).find((e) => e.symbolKey === symbolKey) ?? null;
  }

  function buildSymbolInfo(symbolKey) {
    const entry = symbolIndex[symbolKey];
    const wl = resolveWorklistEntry(symbolKey);
    const parts = parseSymbolKeyParts(symbolKey);
    return {
      symbolKey,
      name: wl?.name ?? extractName(parts),
      filePath: wl?.filePath ?? extractFilePath(parts),
      kind: wl?.kind ?? null,
      range: wl?.range ?? null,
      graphNodeId: entry?.graphNodeId ?? null,
      memoryId: entry?.memoryId ?? null,
      status: entry?.status ?? null,
    };
  }

  function querySymbolContext({ symbolKey, depth }) {
    const config = createDepthConfig(depth);
    const target = buildSymbolInfo(symbolKey);
    if (!target.graphNodeId) {
      return { target, neighbors: [], edges: [], depth_reached: 0 };
    }
    const traversal = traverseGraph({ nodeIds: [target.graphNodeId], maxHops: config.maxHops });
    const neighbors = traversal.nodes
      .filter((n) => n.id !== target.graphNodeId)
      .map((n) => {
        const sk = graphNodeIdToSymbolKeyMap.get(n.id);
        if (sk) return buildSymbolInfo(sk);
        return { graphNodeId: n.id, label: n.label, sourceFile: n.source_file ?? null, symbolKey: null };
      });
    return { target, neighbors, edges: traversal.edges, depth_reached: traversal.depth_reached };
  }

  function queryFileContext({ filePath, depth }) {
    const config = createDepthConfig(depth);
    const normalized = normalizePath(filePath);
    const symbolKeys = filePathToSymbolKeys.get(normalized) ?? [];
    const symbols = symbolKeys.map(buildSymbolInfo);
    const fileNodeIds = (graph.nodes ?? [])
      .filter((n) => normalizePath(n.source_file ?? '') === normalized)
      .map((n) => n.id);
    const outTraversal = traverseGraph({ nodeIds: fileNodeIds, maxHops: config.maxHops });
    const inTraversal = traverseGraph({ nodeIds: fileNodeIds, maxHops: config.maxHops, direction: 'inbound' });
    const fileNodeIdSet = new Set(fileNodeIds);
    const seen = new Set();
    const neighbors = [];
    const edges = [];
    for (const n of [...outTraversal.nodes, ...inTraversal.nodes]) {
      if (fileNodeIdSet.has(n.id) || seen.has(n.id)) continue;
      seen.add(n.id);
      const sk = graphNodeIdToSymbolKeyMap.get(n.id);
      neighbors.push(sk ? buildSymbolInfo(sk) : { graphNodeId: n.id, label: n.label, sourceFile: n.source_file ?? null, symbolKey: null });
    }
    const edgeSet = new Set();
    for (const e of [...outTraversal.edges, ...inTraversal.edges]) {
      const key = `${e.source}->${e.target}`;
      if (!edgeSet.has(key)) { edgeSet.add(key); edges.push(e); }
    }
    const depth_reached = Math.max(outTraversal.depth_reached, inTraversal.depth_reached);
    return { symbols, neighbors, edges, depth_reached };
  }

  function queryImpactScope({ symbolKeys, depth }) {
    const config = createDepthConfig(depth);
    const targets = symbolKeys.map(buildSymbolInfo);
    const nodeIds = targets.map((t) => t.graphNodeId).filter(Boolean);
    const traversal = traverseGraph({ nodeIds, maxHops: config.maxHops, direction: 'inbound' });
    const targetIdSet = new Set(nodeIds);
    const dependents = traversal.nodes
      .filter((n) => !targetIdSet.has(n.id))
      .map((n) => {
        const sk = graphNodeIdToSymbolKeyMap.get(n.id);
        if (sk) return buildSymbolInfo(sk);
        return { graphNodeId: n.id, label: n.label, sourceFile: n.source_file ?? null, symbolKey: null };
      });
    return {
      target: targets.length === 1 ? targets[0] : targets,
      dependents,
      edges: traversal.edges,
      depth_reached: traversal.depth_reached,
    };
  }

  return {
    graphNodeIdToSymbolKey(graphNodeId) {
      return graphNodeIdToSymbolKeyMap.get(graphNodeId) ?? null;
    },
    findSymbolKeyByName(name) {
      return nameToSymbolKeys.get(name) ?? [];
    },
    findSymbolKeysByFilePath(filePath) {
      return filePathToSymbolKeys.get(normalizePath(filePath)) ?? [];
    },
    traverseGraph,
    querySymbolContext,
    queryFileContext,
    queryImpactScope,
  };
}
