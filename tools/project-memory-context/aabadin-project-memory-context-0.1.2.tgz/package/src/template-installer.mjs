import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export { detectAgentType } from './platform.mjs';

export function renderTemplate(content, placeholders) {
  return Object.entries(placeholders).reduce(
    (text, [key, value]) => text.replaceAll(`{{${key}}}`, value),
    content,
  );
}

const SUPPORTED_AGENTS = new Set(['opencode', 'claude-code', 'cursor', 'generic']);

function resolvePackageRoot() {
  return join(dirname(fileURLToPath(import.meta.url)), '..');
}

async function loadBinNames(packageRoot) {
  const packageJson = JSON.parse(await readFile(join(packageRoot, 'package.json'), 'utf8'));
  return {
    PMC_BIN: Object.keys(packageJson.bin ?? {})[0] ?? 'pmc',
    AGENT_MEMORY_CMD: 'npx -y @aabadin/agent-memory-mcp',
  };
}

async function buildPlaceholders(projectRoot, packageRoot) {
  const binNames = await loadBinNames(packageRoot);
  return {
    ...binNames,
    PROJECT_ROOT: projectRoot,
    CONFIG_DIR: '.pmc',
  };
}

async function readTemplate(packageRoot, templatePath) {
  return readFile(join(packageRoot, 'templates', templatePath), 'utf8');
}

async function writeIfMissingOrForced(filePath, content, options = {}) {
  const { force = false } = options;
  if (!force && existsSync(filePath)) return false;
  await mkdir(dirname(filePath), { recursive: true });
  await writeFile(filePath, content, 'utf8');
  return true;
}

function hasBlockMarker(content, marker) {
  return content.includes(`<!-- pmc:${marker} -->`);
}

function replaceOrAppendBlock(content, marker, block) {
  const open = `<!-- pmc:${marker} -->`;
  const close = `<!-- /pmc:${marker} -->`;
  const regex = new RegExp(`${open}[\\s\\S]*?${close}`, 'g');

  if (regex.test(content)) {
    return content.replace(regex, `${open}\n${block}\n${close}`);
  }

  return `${content}\n\n${open}\n${block}\n${close}\n`;
}

function stripBlockMarkers(content, marker) {
  return content
    .replace(new RegExp(`<!-- pmc:${marker} -->|<!-- /pmc:${marker} -->`, 'g'), '')
    .trim();
}

async function installWithBlockMarker({ projectRoot, packageRoot, placeholders, targetFile, templatePath, marker = 'init' }) {
  const targetPath = join(projectRoot, targetFile);
  const snippet = renderTemplate(await readTemplate(packageRoot, templatePath), placeholders);

  let existing = '';
  if (existsSync(targetPath)) {
    existing = await readFile(targetPath, 'utf8');
  }

  if (hasBlockMarker(existing, marker)) {
    const updated = replaceOrAppendBlock(existing, marker, stripBlockMarkers(snippet, marker));
    await writeFile(targetPath, updated, 'utf8');
    return;
  }

  await writeFile(targetPath, snippet, 'utf8');
}

async function installOpencode({ projectRoot, packageRoot, placeholders, globalConfigDir }) {
  const globalDir = globalConfigDir;

  const commandTemplates = [
    'opencode/commands/new-project.md',
    'opencode/commands/get-context.md',
    'opencode/commands/sync-context.md',
    'opencode/commands/sanitize.md',
  ];

  for (const tpl of commandTemplates) {
    const rendered = renderTemplate(await readTemplate(packageRoot, tpl), placeholders);
    const fileName = tpl.split('/').at(-1);
    await writeIfMissingOrForced(join(globalDir, 'commands', fileName), rendered, { force: true });
  }

  const enrichTemplate = renderTemplate(
    await readTemplate(packageRoot, 'opencode/agent/enrich.md'),
    placeholders,
  );
  await writeIfMissingOrForced(join(globalDir, 'agents', 'enrich.md'), enrichTemplate, { force: true });

  const agentsMdPath = join(projectRoot, 'AGENTS.md');
  const autostartBlock = renderTemplate(
    await readTemplate(packageRoot, 'opencode/autostart-snippet.md'),
    placeholders,
  );

  let existing = '';
  if (existsSync(agentsMdPath)) {
    existing = await readFile(agentsMdPath, 'utf8');
  }

  const updated = replaceOrAppendBlock(existing, 'autostart', autostartBlock.trim());
  await writeFile(agentsMdPath, updated, 'utf8');
}

async function installClaudeCode({ projectRoot, packageRoot, placeholders }) {
  await installWithBlockMarker({
    packageRoot,
    placeholders,
    projectRoot,
    targetFile: 'CLAUDE.md',
    templatePath: 'claude-code/CLAUDE.md.snippet',
  });
}

async function installCursor({ projectRoot, packageRoot, placeholders }) {
  await installWithBlockMarker({
    packageRoot,
    placeholders,
    projectRoot,
    targetFile: '.cursorrules',
    templatePath: 'cursor/.cursorrules.snippet',
  });
}

async function installGeneric({ projectRoot, packageRoot, placeholders }) {
  const readme = renderTemplate(
    await readTemplate(packageRoot, 'generic/README-SETUP.md'),
    placeholders,
  );
  await writeFile(join(projectRoot, 'README-SETUP.md'), readme, 'utf8');
}

const INSTALLERS = {
  'claude-code': installClaudeCode,
  cursor: installCursor,
  generic: installGeneric,
  opencode: installOpencode,
};

export async function installAgentTemplates({
  projectRoot,
  agent,
  packageRoot,
  globalConfigDir,
}) {
  if (!SUPPORTED_AGENTS.has(agent)) {
    throw new Error(`Unsupported agent type: ${agent}. Supported: ${[...SUPPORTED_AGENTS].join(', ')}`);
  }

  const pkgRoot = packageRoot ?? resolvePackageRoot();
  const placeholders = await buildPlaceholders(projectRoot, pkgRoot);

  await INSTALLERS[agent]({
    globalConfigDir: globalConfigDir ?? join(projectRoot, '.pmc'),
    packageRoot: pkgRoot,
    placeholders,
    projectRoot,
  });
}
