# @aabadin/project-memory-context

Portable project memory context CLI — bootstraps semantic enrichment workflows for any AI coding agent.

This package installs and wires together:

- a project bootstrapper (`pmc bootstrap` / `pmc setup`)
- a local semantic MCP backed by Ollama (`pmc-local-model`)
- an `agent-memory` MCP registration using `npx -y @aabadin/agent-memory-mcp`
- command/workflow templates for `project-memory-context`
- helper CLIs and artifact management for the semantic enrichment loop

## What it installs for you

The setup flow is designed to resolve everything automatically except:

- installing Ollama itself
- pulling/downloading your local model

The setup flow handles:

- asking for `OLLAMA_BASE_URL`
- asking for `OLLAMA_MODEL`
- installing `graphifyy` with Python/pip
- creating `.planning/project-memory-context/`
- writing project install state
- registering MCP servers in `.mcp.json`
- registering the plugin in `.opencode/opencode.json` when using OpenCode
- copying `project-memory-context.md` and `project-memory-context workflow.md` into the target project

## Install

Install the package globally, or run it with `npx`, then run setup inside the target repository.

```bash
npm install -g @aabadin/project-memory-context
pmc setup
```

Without a global install:

```bash
npx @aabadin/project-memory-context setup
```

## Setup prompts

`pmc setup` asks for:

- Ollama base URL, default `http://localhost:11434`
- Ollama model name, default `deepseek-coder-v2:16b-ctx32k`

It then attempts to install:

```bash
python -m pip install graphifyy
```

or an equivalent Python launcher depending on platform.

## Resulting project files

After setup, the target project contains:

```text
.mcp.json
.planning/project-memory-context/install.json
project-memory-context.md
project-memory-context workflow.md
```

## Runtime layout

During workflow execution, artifacts accumulate under:

```text
.planning/project-memory-context/
  intake/
  graph/
  enrichment/
  runs/
```

## MCP servers

The bootstrap flow writes `.mcp.json` with an `agent-memory` server that runs:

```bash
npx -y @aabadin/agent-memory-mcp
```

OpenCode plugin integration may also inject local MCP entries at runtime using values from `.planning/project-memory-context/install.json`:

- `pmc-local-model`
- `pmc-agent-memory`

`pmc-local-model` exposes a semantic report tool backed by Ollama.

`pmc-agent-memory` points at the public `agent-memory-mcp` binary when plugin injection is used.

## Workflow order

1. `stage-a`
   - intake
   - brainstorming clarification
   - graphify structural mapping

2. `stage-b`
   - build worklist
   - prepare semantic jobs
   - call `pmc-local-model`
   - materialize `*.memory.json`
   - store/update in `pmc-agent-memory`
   - materialize `*.result.json`
   - finalize or fail each symbol

## Development verification

Run the local test suite:

```bash
node --test "tools/project-memory-context/tests/*.test.mjs"
```
